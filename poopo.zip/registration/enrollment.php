<?php
include_once('includes/config.php');
 if(isset($_POST['submit'])){
     $firstName      = $_POST['firstName'];
     $surname        = $_POST['surname'];
     $lastName       = $_POST['lastName'];
     $nationality    = $_POST['nationality'];
     $gender         = $_POST['gender'];
     $age            = $_POST['age'];
     $fms            = $_POST['fms'];
     $district       = $_POST['district'];
     $mobile         = $_POST['mobile'];
     $email          = $_POST['email'];


     $query=mysqli_query($con,"INSERT INTO tblenrollment(firstName,surname,lastName,nationality,gender,age,fms,district,mobile,email) values('$firstName','$surname','$lastName','$nationality','$gender','$age','$fms','$district','$mobile','$email')");
if($query){
echo "<script>alert('Enrollment Details sent successfully.');</script>";
echo "<script type='text/javascript'> document.location = 'about.php'; </script>";
} else {
echo "<script>alert('Something went wrong. Please try again.');</script>";
}

 }

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Registration Enrollment System </title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Inter:wght@600&family=Lobster+Two:wght@700&display=swap" rel="stylesheet">
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
 <?php include_once('includes/header.php');?>


        <!-- Page Header End -->
        <div class="container-xxl py-5 page-header position-relative mb-5">
            <div class="container py-5">
                <h1 class="display-2 text-white animated slideInDown mb-4">Program Enrollment</h1>
                <nav aria-label="breadcrumb animated slideInDown">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="about.php">Home</a></li>
                        <li class="breadcrumb-item text-white active" aria-current="page">Program Enrollment</li>
                    </ol>
                </nav>
            </div>
        </div>
        <!-- Page Header End -->


        <!-- Appointment Start -->
         <div class="container-xxl py-5">
             <div class="container">
                 <div class="bg-light rounded">
                     <div class="row g-0">
                         <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                             <div class="h-100 d-flex flex-column justify-content-center p-5">
                                 <h1 class="mb-4">Register Here</h1>
                                 <form method="post">
                                     <div class="row g-3">
                                         <div class="col-sm-6">
                                             <div class="form-floating">
                                                 <input type="text" class="form-control border-0" id="firstName" name="firstName" placeholder="Father Name" required>
                                                 <label for="gname">First Name</label>
                                             </div>
                                         </div>

                                         <div class="col-sm-6">
                                             <div class="form-floating">
                                                 <input type="text" class="form-control border-0" id="surname" name="surname" placeholder="Father Name" required>
                                                 <label for="gname">Surname</label>
                                             </div>
                                         </div>

                                         <div class="col-sm-6">
                                             <div class="form-floating">
                                                 <input type="text" class="form-control border-0" id="lastName" name="lastName" placeholder="Father Name" required>
                                                 <label for="gname">Last Name</label>
                                             </div>
                                         </div>

                                         <div class="col-sm-6">
                                             <div class="form-floating">
                                                 <input type="text" class="form-control border-0" id="nationality" name="nationality" placeholder="Father Name" required>
                                                 <label for="gname">Nationality</label>
                                             </div>
                                         </div>
                                         <div class="col-sm-6">
                                             <div class="form-floating">
                                                 <input type="text" class="form-control border-0" id="gender" name="gender" placeholder="Mother Name" required>
                                                 <label for="gmail">Gender</label>
                                             </div>
                                         </div>

                                          <div class="col-sm-6">
                                             <div class="form-floating">
                                                 <input type="text" class="form-control border-0" id="age" name="age" placeholder="Parents Mobile No." required>
                                                 <label for="gname">Age</label>
                                             </div>
                                         </div>

                                         <div class="col-sm-6">
                                             <div class="form-floating">
                                                 <input type="text" class="form-control border-0" id="fms" name="fms" placeholder="Child Name" required>
                                                 <label for="cname">Federal Member State</label>
                                             </div>
                                         </div>
                                         <div class="col-sm-6">
                                             <div class="form-floating">
                                                 <input type="text" class="form-control border-0" id="district" name="district" placeholder="Child Name" required>
                                                 <label for="cage">District</label>
                                             </div>
                                         </div>

                                         <div class="col-sm-12">
                                         <div class="form-floating">
                                             <input type="text" class="form-control border-0" id="mobile" name="mobile" placeholder="Child Name" required>
                                             <label for="cage">Mobile</label>
                                             </div>
                                         </div>

                                         <div class="col-sm-12">
                                             <div class="form-floating">
                                                 <input type="email" class="form-control border-0" id="email" name="email" placeholder="Parents Email" required>
                                                 <label for="gmail">Email</label>
                                             </div>
                                         </div>
                                         <div class="col-12">
                                             <button class="btn btn-primary w-100 py-3" type="submi" name="submit">Submit</button>
                                         </div>
                                     </div>
                                 </form>
                             </div>
                         </div>
                         <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s" style="min-height: 400px;">
                             <div class="position-relative h-100">
                                 <img class="position-absolute w-100 h-100 rounded" src="img/regg.jpeg" style="object-fit: cover;">
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         </div>

        <!-- Appointment End -->


        <!-- Footer Start -->
            <?php include_once('includes/footer.php');?>       
             <!-- Footer End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>




<!--<div class="container">-->
<!--    <div class="row">-->
<!--        <div class="col-sm-3">-->
<!--            <h1>Registration</h1>-->
<!--            <p>Fill the following spaces with your details</p>-->
<!--            <hr class="mb-3">-->
<!---->
<!--            <label for="firstName"><b>First Name</b></label>-->
<!--            <input class="form-control" type="text" name="firstName" required>-->
<!---->
<!--            <label for="surname"><b>Surname</b></label>-->
<!--            <input class="form-control" type="text" name="surname" required>-->
<!---->
<!--            <label for="lastName"><b>Last Name</b></label>-->
<!--            <input class="form-control" type="text" name="lastName">-->
<!---->
<!--            <label for="nationality"><b>Nationality</b></label>-->
<!--            <input class="form-control" type="text" name="nationality" required>-->
<!---->
<!--            <label for="gender"><b>Gender</b></label>-->
<!--            <input class="form-control" type="text" name="gender" required>-->
<!---->
<!--            <label for="age"><b>Age</b></label>-->
<!--            <input class="form-control" type="text" name="age" required>-->
<!---->
<!--            <label for="fms"><b>Federal Member State</b></label>-->
<!--            <input class="form-control" type="text" name="fms" required>-->
<!---->
<!--            <label for="district"><b>District</b></label>-->
<!--            <input class="form-control" type="text" name="district" required>-->
<!---->
<!--            <label for="mobile"><b>Mobile</b></label>-->
<!--            <input class="form-control" type="text" name="mobile" required>-->
<!---->
<!--            <label for="email"><b>Email</b></label>-->
<!--            <input class="form-control" type="EMAIL" name="email" required>-->
<!---->
<!--            <hr class="mb-3">-->
<!--            <div class="col-12">-->-->
<!--                <button class="btn btn-primary w-100 py-3" type="submit" name="submit">Submit</button>-->
<!--            </div>-->
<!--            <!--             <input class="btn btn-primary" type="submit" name="register" value="Register">-->-->
<!--        </div>-->
<!--    </div>-->
<!--</div>-->

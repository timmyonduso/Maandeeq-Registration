   <div class="container-fluid bg-dark text-white-50 footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s">
            <div class="container py-5">
                <div class="row g-5">

                    <div class="col-lg-4 col-md-6">
                        <h3 class="text-white mb-4">Get In Touch</h3>
                        <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Maka Al Mukarama Road, Mogadishu, Somalia</p>
                        <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+252-613061982</p>
                        <p class="mb-2"><i class="fa fa-envelope me-3"></i>info@maandeeqmh.org</p>
                        <div class="d-flex pt-2">
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-youtube"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h3 class="text-white mb-4">Links</h3>
                        <a class="btn btn-link text-white-50" href="https://maandeeqmh.org/about-us/">About Us</a>
                        <a class="btn btn-link text-white-50" href="admin/">Admin Login</a>
                    </div>
                    <div class="col-lg-5 col-md-6">
                        <h3>Thank you!</h3>
                    </div>
                
                </div>
            </div>
    
        </div>